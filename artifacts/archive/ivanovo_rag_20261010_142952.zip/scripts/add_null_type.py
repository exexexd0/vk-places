#!/usr/bin/env python3
"""Temporary step: ensure every place has a type field.

Later dumps already include type. This script only fills the key when it
is missing and never overwrites an existing value.
"""

import argparse
import json
import sys
from pathlib import Path


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Add type=null to places that lack the field."
    )
    parser.add_argument(
        "path",
        nargs="?",
        default="Иваново_best.json",
        help="JSON array of places (default: Иваново_best.json)",
    )
    args = parser.parse_args()
    path = Path(args.path)

    with path.open(encoding="utf-8") as handle:
        places = json.load(handle)

    if not isinstance(places, list):
        print(f"{path}: expected a JSON array", file=sys.stderr)
        return 1

    added = 0
    already = 0
    for place in places:
        if not isinstance(place, dict):
            print(f"{path}: array contains a non-object", file=sys.stderr)
            return 1
        if "type" in place:
            already += 1
            continue
        place["type"] = None
        added += 1

    with path.open("w", encoding="utf-8") as handle:
        json.dump(places, handle, ensure_ascii=False, indent=2)
        handle.write("\n")

    print(f"added type=null: {added}; already had type: {already}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
