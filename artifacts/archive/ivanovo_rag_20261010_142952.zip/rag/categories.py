CANONICAL_CATEGORIES = (
    "food",
    "culture",
    "nature",
    "sight",
    "entertainment",
    "mall",
    "station",
    "sport",
)

CATEGORY_LABELS = {
    "food": "еда",
    "culture": "культура",
    "nature": "природа",
    "sight": "достопримечательность",
    "entertainment": "развлечения",
    "mall": "торговый центр",
    "station": "вокзал",
    "sport": "спорт",
}

BLACKLIST_PARTS = (
    "бухгалтер",
    "лизинг",
    "автосервис",
    "шиномонтаж",
    "склад",
    "оптом",
)

WHITELIST = {
    "Кофейня": "food",
    "Кафе": "food",
    "Ресторан": "food",
    "Пекарня": "food",
    "Быстрое питание": "food",
    "Пиццерия": "food",
    "Бар": "food",
    "Суши-бар": "food",
    "Кондитерская": "food",
    "Кофе с собой": "food",
    "Паб": "food",
    "Кальян-бар": "food",
    "Культурный центр": "culture",
    "Клуб виртуальной реальности": "entertainment",
    "Торговый центр": "mall",
}


def classify_rubric(rubric: str | None) -> tuple[str | None, str]:
    if rubric is None or not str(rubric).strip():
        return None, "missing_type"
    text = str(rubric).strip()
    lowered = text.casefold()
    if any(part in lowered for part in BLACKLIST_PARTS):
        return None, "blacklist"
    category = WHITELIST.get(text)
    if category is None:
        return None, "not_in_whitelist"
    return category, "kept"
